<?php
 

// create a variable

if (isset($_POST)) {  
$Number=$_POST['Number'];
$Company=$_POST['Company'];
$Category=$_POST['Category'];
$Address=$_POST['Address'];
$City=$_POST['City'];
$Pincode=$_POST['Pincode'];
$Country=$_POST['Country'];
$Website=$_POST['Website'];
$Landline=$_POST['Landline'];
$Mobile=$_POST['Mobile'];
$Emailid1=$_POST['Emailid1'];
$Emailid2=$_POST['Emailid2'];
}
//create connection 
$connect=mysqli_connect('localhost','root','','leadgeneration');
$check="SELECT COUNT(*) FROM leadg WHERE Number='$_POST[Number]'  ";
$result=mysqli_query($connect,$check);
$data = mysqli_fetch_array($result, MYSQLI_NUM);
if($data[0] > 1) {
    echo "<b>User Already Exists</b><br/>";
}

else
{
    $newUser="INSERT INTO leadg(Number,Company,Category,Address,City,Pincode,Country,Website,Landline,Mobile,Emailid1,Emailid2)
				VALUES('$Number','$Company','$Category','$Address','$City','$Pincode','$Country','$Website','$Landline','$Mobile','$Emailid1','$Emailid2')";
    if (mysqli_query($connect,$newUser))
    {
        echo "<b>Information Added</b><br/>";
    }
    else
    {
        echo "<b>Error adding user in database</b><br/>";
    }
}
 
/*if(mysqli_connect_errno($connect))
{
		echo 'Failed to connect';
}

//Execute the query

mysqli_query($connect,"INSERT INTO leadg(Number,Company,Category,Address,City,Pincode,Country,Website,Landline,Mobile,Emailid1,Emailid2)
				VALUES('$Number','$Company','$Category','$Address','$City','$Pincode','$Country','$Website','$Landline','$Mobile','$Emailid1','$Emailid2')");
if(mysqli_affected_rows($connect) > 0)
{
	echo "<p><b>Information Added</b></p>";
	
} else {
	echo "<b>Information NOT Added<b><br />";
	echo mysqli_error ($connect);
	
}*/